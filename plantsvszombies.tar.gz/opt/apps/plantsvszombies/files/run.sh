#!/bin/bash

#   Copyright (C) 2016 Deepin, Inc.
#
#   Author:     Li LongYu <lilongyu@linuxdeepin.com>
#               Peng Hao <penghao@linuxdeepin.com>
#               zty199 <zty2864@gmail.com>

BOTTLENAME="Deepin-plantsvszombies"
APPVER="1.13deepin0"
EXEC_PATH="c:/Program Files/plantsvszombies/PlantsVsZombies.exe"

export MIME_TYPE=""
export DEB_PACKAGE_NAME="plantsvszombies"
export APPRUN_CMD="wine"

if [ -n "$EXEC_PATH" ];then
    /opt/deepinwine/tools/run_v3.sh $BOTTLENAME $APPVER "$EXEC_PATH" "$@"
else
    /opt/deepinwine/tools/run_v3.sh $BOTTLENAME $APPVER "uninstaller.exe" "$@"
fi
