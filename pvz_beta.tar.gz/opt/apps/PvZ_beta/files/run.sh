#!/bin/bash

#   Copyright (C) 2021 zzy-ac, Inc.
#
#   Author:     zzy-ac <1304024859@qq.com>


BOTTLENAME="PvZ_beta"
APPVER="1.13deepin0"
EXEC_PATH="c:/Program Files/PvZ_beta/beta6.15.01.exe"

export MIME_TYPE=""
export DEB_PACKAGE_NAME="PvZ_beta"
export APPRUN_CMD="wine"

if [ -n "$EXEC_PATH" ];then
    /opt/deepinwine/tools/run_v3.sh $BOTTLENAME $APPVER "$EXEC_PATH" "$@"
else
    /opt/deepinwine/tools/run_v3.sh $BOTTLENAME $APPVER "uninstaller.exe" "$@"
fi
