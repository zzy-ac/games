#! /bin/bash
dosbox -conf /opt/durapps/com.pal.dosbox/Pal.conf
